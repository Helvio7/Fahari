function modal(){
            document.querySelector(".confirm_login").style.display="flex"
            document.querySelector(".img_page_login").style.display="none"
            }

 formulario = document.querySelector(".formulario");
formulario.addEventListener("submit", event => send(event));

async function send(event){
    event.preventDefault()
    try{
         formulario = event.target
         form = new FormData(formulario)

         response = await fetch("../php/login.php",{
            method: "POST",
            body: form
        }) 
        const response_server = await response.json()
        console.log(response_server)
        
        if(response_server.status === "ok"){
            if(response_server.role === 'admin'){
                modal()
            setTimeout(function(){
                   window.location.href="../html/admin.php"
            },3000)     
        } else{
           modal()
            setTimeout(function(){
                window.location.href = "../html/index_copy.html"
            },3000)         
}
        }
        else{
            alert(response_server.message)
        }
        
    }catch(error){
        console.error("Erro ao enviar o formulário:", error)
    }
        
}
