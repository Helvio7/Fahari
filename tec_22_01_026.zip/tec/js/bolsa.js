      if(sess == adm){
        document.querySelector("#admin").style.display="flex"
    }
    async function favorito(bolsa_id) {
        event.preventDefault()
        await fetch("../php/favorito.php",{
            method: 'POST',
            body: "bolsa_id=" + bolsa_id + "& user_id=1"
        })
        alert("Bolsa adiciona aos favoritos")
    }