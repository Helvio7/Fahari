async function apagar(id){
    
    event.preventDefault()
    if(!confirm("Deseja apagar")) return;

    await fetch("../php/apagar.php",{
        method: 'POST',
         body: JSON.stringify({ id })
    })
    location.reload()

}