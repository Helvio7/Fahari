function cadastro_bolsa(){
    window.location.href="../html/cadastrar_bolsa.php"
}
function list_bolsas(){
    window.location.href="../html/bolsas_de_estudo_admin.php"
}
function gerence_users(){
    window.location.href="../html/users_sign.php"
}