<?php

$conexao = new PDO("mysql:host=localhost;dbname=lixo","root","");
$data = json_decode(file_get_contents("php://input"), true);
$id = $data['id'];

$stmt = $conexao->prepare("DELETE FROM cadastro_bolsa WHERE id=?");
$stmt->execute([$id]);
$tmt = $conexao->prepare("DELETE FROM users WHERE id=?");
$tmt->execute([$data['id']]);