<?php

$conexao = new PDO("mysql:host=localhost;dbname=lixo","root","");

$sql = $conexao->prepare("UPDATE cadastro_bolsa set (nome_bolsa, descricao, instituicao, tipo_bolsa, area_estudo, requisitos, n_vagas, data_encerramento, data_inicio) Values (?,?,?,?,?,?,?,?,?)");

$sql->execute([
$_POST['nome_bolsa'],
$_POST['descricao_bolsa'],
$_POST['instituicao'],
$_POST['tipo_bolsa'],
$_POST['areas_estudo'],
$_POST['requisitos'],
$_POST['n_vagas'],
$_POST['date_start'],
$_POST['data_encerrar']
]);

echo("Dados atualizados");
exit();