<?php

session_start();
header("Content-Type: application/json");

try{

$conexao = new PDO("mysql:host=localhost;dbname=lixo","root","");

 $email = $_POST['email'] ?? null;
    $password = $_POST['password' ] ?? null;
    
    $select = "SELECT id, nome, email, senha, role FROM users WHERE email = ? AND senha = ? LIMIT 1";

    $stmt = $conexao->prepare($select);
    $stmt->execute([$email,$password]);

    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
     
        $_SESSION['user_id'] = $usuario['id'];
        $_SESSION['user_email'] = $usuario['email'];
        $_SESSION['role'] = $usuario['role'];

        echo json_encode([
            "status" => "ok",  "role" => $usuario['role']
            ]);
    } 
    else {
        echo json_encode(["message" => "Usuário ou senha incorretos", "status" => "error"]);
    }
} catch (PDOException $e) {
    echo json_encode(["status" => "erro", "mensagem" => "erro no servidor"]);
}

   

?>  