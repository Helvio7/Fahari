<?php

$conexao = new PDO("mysql:host=localhost;dbname=lixo","root","");
$data = json_decode(file_get_contents("php://input"), true);

$user_id = $data['user_id'];
$bolsa_id = $data['bolsa_id'];

$stmt = $conexao->prepare("INSERT INTO favorito(user_id, bolsa_id) values (?,?)");
$stmt->execute([$user_id, $bolsa_id]);