<?php

$conexao = new PDO("mysql:host=localhost;dbname=lixo","root","");

$nome_bolsa = $_POST['nome_bolsa'];
$imagem = $_FILES['imagem'];
$pasta = "../images/";
$descricao = $_POST['descricao_bolsa'];
$instituicao = $_POST['instituicao'];
$tipo = $_POST['tipo_bolsa'];
$area = $_POST['areas_estudo'];
$requisitos = $_POST['requisitos'];
$numero_vagas = $_POST['n_vagas'];
$date_start = $_POST['date_start'];
$data_encerramento = $_POST['data_encerrar'];


$extensao = pathinfo($imagem['name'], PATHINFO_EXTENSION);
$nome_img = uniqid().".".$extensao;
$path = $pasta.$nome_img;


if(move_uploaded_file($imagem['tmp_name'], $path)){
$sql = "INSERT INTO cadastro_bolsa(nome_bolsa, descricao, instituicao, tipo_bolsa, area_estudo, requisitos, n_vagas, data_encerramento, data_inicio, imagem) values (?,?,?,?,?,?,?,?,?,?)";

$transporte = $conexao->prepare($sql);
$stmt = $transporte->execute([$nome_bolsa, $descricao, $instituicao, $tipo, $area, $requisitos, $numero_vagas, $data_encerramento, $date_start, $imagem]);

if(isset($stmt)){
    echo("Cadastro de bolsa de estudo realizado com sucesso");
}
else{
    echo("Erro ocorrido no cadastro");
}
}
else{
    echo("Erro ao fazer upload");
}



$listar = "SELECT * FROM cadastro_bolsa ORDER BY id DESC";
$stmt2 = $conexao->query($listar);

$bolsas_study = $stmt2->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($bolsas_study);