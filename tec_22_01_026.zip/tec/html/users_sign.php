<?php

session_start();
if($_SESSION['role'] !=='admin'){
    header("Location: ../html/login.php");
    exit();
}

$conexao = new pdo("mysql:host=localhost;dbname=lixo","root","");

$sql = "SELECT * FROM users";

$stmt = $conexao->query($sql);
$user = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/style-header-footer.css">
   
     <link rel="stylesheet" href="../css/users_sign.css">
    
</head>
<body id="body">
    <header id="header">
        <div class="name_plataform">
            <div class="icon_study">
               
            </div>
            <span class="fahari">Fahari</span>
        </div>
        
        <nav class="links">
            <a class="a" href="../html/index.html">INÍCIO</a>
            <a class="a" href="../html/bolsa.php">BOLSAS</a>
            <a class="a" href="../html/instrucoes.html">INSTRUÇÕES</a>
            <a class="a" href="#info_sobre_nos">SOBRE</a>
            <a class="a" href="#contactos2">CONTACTO</a>
            <a class="a" href="../html/admin.php">ADMIN</a>
        </nav>
       
        <div class="registro">
            <button class="login_cadastro" id="btn_logout">Terminar sessão</button>
        </div>
    </header>
    <div class="div_span_frase"><Span class="frase_span">Usuários logados no sistema</Span> </div>
            <main class="main">

             <?php 
            foreach($user as $users):  
            ?>
            <div class="card">
                <div class="top">User</div>
                <div class="baixo">
                    <span><span class="atributo">ID:</span><?= $users['id'] ?></span>

                    <span><span class="atributo">Nome do usuário:</span> <?= $users['nome'] ?></span>

                    <span><span class="atributo">Email:</span> <?= $users['email'] ?></span>

                    <span><span class="atributo">Número telefônico:</span> <?= $users['number_phone'] ?></span>

                    <span><span class="atributo">Data de nascimento:</span> <?= $users['data_nasc'] ?></span>
                </div>
                <div class="footer_card">
                    <button onclick="apagar(<?= $users['id'] ?>)" id="delete_button">Delete User</button>
                </div>
            </div>

             <?php endforeach; ?>
            </main>
    </div>


     <div style="margin-bottom: 100px"></div>


     <section class="section_ultimate">
        <div id="body2">
        <div class="dentro_body2">
         <div class="img"></div>
         <div class="info_sobre_nos" style="times ">
            <span>Sobre Nós</span>
            <p>A Fahari é uma plataforma dedicada <br> a conectar estudantes com <br> oportunidades de <br> bolsas de estudo em todo o mundo.</p>
         </div>

          <div class="img2"></div>
         <div class="info_sobre_nos">
            <span>Missão e Visão</span>
            <p>Nossa missão é democratizar <br> o acesso à educação superior, <br> conectando estudantes talentosos. </p>
        
            <span>- ✨ - Um livro não morde, <br> seu conhecimento é capaz de <br> preencher-te sendo um bolseiro <br> não pode ser alérgico a eles.</span>
         </div>
        </div>
        </div>
        
        <div id="contactos2">
            <div class="nome_contactos">
                    <h3>Fahari</h3> <br> <br>
                   <span> <div id="figura" class="figura1"></div> <span style="margin-top:5px;" >fahari_study@gmail.com</span></span><br>
                    <span> <div id="figura" class="figura2"></div> <span style="margin-top:5px;">+244 972 474 506</span></span> <br>
                    <span><div id="figura" class="figura3"></div><span style="margin-top:5px;">_fahari_study.ao</span></span>
                </ul>
            </div>
            <div class="link_rapidos">
                     <h3>Links Rápidos</h3> <br> <br>
                    <span> <a href="../html/homepage.html">Início</a></span> <br>
                    <span><a href="../html/bolsas_de_estudo.php">Bolsas</a></span> <br> 
                    <span><a href="../html/sobre_nos.html">Sobre</a></span>
                </ul>
            </div>
            <div class="service">
                   <h3>Adicionais</h3> <br> <br>
                    <span><a href="">Favoritos</a></span> <br>
                    <span><a href="">Notícias</a></span>
            </div>
        </div>

     </section>
         <div class="direitos_reservados">
   <span>© 2025 Fahari. Todos os direitos reservados.</span>
     </div>
</body>
</html>
<script src="../js/logout.js"></script>
<script src="../js/apagar.js"></script>