<?php

session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: ../../../../tec/html/login.php");
    exit();
}

$conexao = new pdo("mysql:host=localhost;dbname=lixo","root","");

$sql = "SELECT * FROM cadastro_bolsa";

$stmt = $conexao->query($sql);
$bolsas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/bolsa.css">
    <link rel="stylesheet" href="../css/style-header-footer.css">
</head>
<body>
    <header>    
        
        <div class="name_plataform">
            <div class="icon_study">
               
            </div>
            <span class="fahari">Fahari</span>
        </div>
        <nav class="links">
            <a class="a" href="../html/index.html">INÍCIO</a>
            <a class="a" href="../html/bolsa.php">BOLSAS</a>
            <a class="a" href="../html/instrucoes.html">INSTRUÇÕES</a>
            <a class="a" href="#info_sobre_nos">SOBRE</a>
            <a class="a" href="#contactos2">CONTACTO</a>
            <a id="admin" class="a" href="../html/admin.php">ADMIN</a>
        </nav>
        <div class="registro">
             <button class="login_cadastro" id="btn_logout">Terminar sessão</button>
        </div>
    </header>

     <div class="h1">
        <h1>Descubra bolsas de estudo</h1>
        <div>
            <input type="text" name="pesquisa_bolsa" id="pesquisa_bolsa" placeholder="Procure de forma rápida e fácil">
            <div id="pesquisa"></div>
        </div>
        
    </div>


    <main id="corpo_infor">

        <section class="corpo_bolsas"> 

           <?php 
            foreach($bolsas as $bolsa):  
            ?>
        <div class="card">
           <div class="img_bolsa" id="img_oxford"></div>
            <div class="infor_bolsa">
              <span><span class="title">Name:</span> <?= $bolsa['nome_bolsa']?> </span> 

                <span><span class="title" >Universidade:</span> <?= $bolsa['instituicao'] ?> </span>

                <span><span class="title" >Especialização:</span> <?= $bolsa['area_estudo'] ?> </span>

                <span><span class="title" >Detalhes:</span> <?= $bolsa['descricao'] ?> </span>

                <span><span class="title" >Tipo de bolsa:</span> <?= $bolsa['tipo_bolsa'] ?> </span>

                <span><span class="title" >Nº Vagas:</span> <?= $bolsa['n_vagas'] ?> </span>

                <span><span class="title" >Data de início:</span> <?= $bolsa['data_inicio'] ?> </span>

                <span><span class="title" >Data de fim:</span> <?= $bolsa['data_encerramento'] ?> </span>
            </div>
            <div class="div_button">
                <button id="favoritos" onclick="favorito(<?= $bolsa['id']?>)">Favoritos</button>
            </div>
        </div>
        <?php endforeach; ?>


        
        </section>
    </main>
  


    <section class="section_ultimate">
        <div id="body2">
        <div class="dentro_body2">
         <div class="img"></div>
         <div class="info_sobre_nos">
            <span>Sobre Nós</span>
            <p>A Fahari é uma plataforma dedicada <br> a conectar estudantes com oportunidades <br> de bolsas de estudo em todo o mundo.</p>
         </div>

          <div class="img2"></div>
         <div class="info_sobre_nos" id="info_sobre_nos">
            <span>Missão e Visão</span>
            <p>Nossa missão é democratizar <br> o acesso à educação superior, <br> conectando estudantes talentosos. </p>
        
            <span>- ✨ - Um livro não morde, <br> seu conhecimento é capaz de te preencher, <br> um bolseiro não pode ser alérgico a eles</span>
         </div>
        </div>
        </div>
        
        <div id="contactos2">
            <div class="nome_contactos">
                    <h3>Fahari</h3> <br> <br>
                   <span> <div id="figura" class="figura1"></div> <span style="margin-top:5px;" >fahari_study@gmail.com</span></span><br>
                    <span> <div id="figura" class="figura2"></div> <span style="margin-top:5px;">+244 972 474 506</span></span> <br>
                    <span><div id="figura" class="figura3"></div><span style="margin-top:5px;">_fahari_study.ao</span></span>
                </ul>
            </div>
            <div class="link_rapidos">
                     <h3>Links Rápidos</h3> <br> <br>
                    <span> <a href="../html/homepage.html">Início</a></span> <br>
                    <span><a href="../html/bolsas_de_estudo.php">Bolsas</a></span> <br> 
                    <span><a href="../html/sobre_nos.html">Sobre</a></span>
                </ul>
            </div>
            <div class="service">
                    <h3>Adicionais</h3> <br> <br>
                    <span><a href="">Favoritos</a></span> <br>
                    <span><a href="">Notícias</a></span>
            </div>
        </div>
           
     </section>
     <div class="direitos_reservados">
   <span>© 2025 Fahari. Todos os direitos reservados.</span>
     </div>
</body>
</html>
<script src="../js/login.js"></script>
<script src="../js/logout.js"></script>
<script src="../js/bolsa.js"></script>