-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 21/01/2026 às 13:07
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `lixo`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `cadastro_bolsa`
--

CREATE TABLE `cadastro_bolsa` (
  `id` int(11) NOT NULL,
  `nome_bolsa` varchar(90) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `instituicao` varchar(90) DEFAULT NULL,
  `tipo_bolsa` enum('parcial','integral','nacional','internacional') DEFAULT NULL,
  `area_estudo` varchar(100) DEFAULT NULL,
  `requisitos` text DEFAULT NULL,
  `n_vagas` int(11) DEFAULT NULL,
  `data_encerramento` date DEFAULT NULL,
  `data_inicio` date DEFAULT NULL,
  `imagem` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `cadastro_bolsa`
--

INSERT INTO `cadastro_bolsa` (`id`, `nome_bolsa`, `descricao`, `instituicao`, `tipo_bolsa`, `area_estudo`, `requisitos`, `n_vagas`, `data_encerramento`, `data_inicio`, `imagem`) VALUES
(6, 'Data ciense ', 'Bolsa para estudantes recorrentes as áreas de tecnologia, especialmente em inovação e foco em IA', 'Harvard', 'internacional', 'Inteligência Artificial ', 'Média acima de 17 valores.\r\nHistórico escolar', 50, '2026-02-01', NULL, NULL),
(7, 'Data ciense ', 'Bolsa para estudantes recorrentes as áreas de tecnologia, especialmente em inovação e foco em IA', 'Harvard', 'internacional', 'Inteligência Artificial ', 'Média acima de 17 valores.\r\nHistórico escolar', 50, '2026-02-01', NULL, NULL),
(8, 'Data ciense ', 'Bolsa para estudantes recorrentes as áreas de tecnologia, especialmente em inovação e foco em IA', 'Harvard', 'internacional', 'Inteligência Artificial ', 'Média acima de 17 valores.\r\nHistórico escolar', 50, '2026-02-01', NULL, NULL),
(26, 'a', 'z', 'a', 'integral', 'H', 'x', 10, '2026-12-31', '2026-01-22', NULL),
(27, 'Data ciense ', 'as', 'as', 'nacional', 'Inteligência Artificial ', 'as', 8, '2026-01-23', '2026-01-01', NULL),
(28, 'Chevenning', 'AAAAAA', 'Stanford', 'internacional', 'IA', 'A', 120, '2026-03-21', '2026-01-12', NULL),
(29, 'Merengue', 'Bolsa de estudo para atletas e amantes de desporto oferecidas pelo Real Madrid', 'Castilha', 'internacional', 'Futebol', 'Faixa etária, dos 7-15 anos de idade.\r\nSaber jogar futebol.\r\nCarta de recomendação', 50, '2026-02-02', '2025-12-20', NULL),
(30, 'TT2', 'Bolsa de futebol', 'Lamacia', 'internacional', 'Futebologia', 'Saber jogar bem', 30, '2026-03-17', '2025-12-31', 'Array'),
(31, 'HC3', 'União e alegria', 'Harvard', 'integral', 'Comércio', 'Saber ler e escrever', 70, '2026-03-28', '2025-12-30', 'Array'),
(32, 'Chevenning', 'sjhjoojfojkojokjf', 'HC school', 'internacional', 'IA', 'DTFUYHIBJJNKLMNJK', 50, '2026-03-30', '2026-01-19', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nome` varchar(90) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `number_phone` int(11) DEFAULT NULL,
  `data_nasc` date DEFAULT NULL,
  `senha` varchar(90) DEFAULT NULL,
  `role` enum('admin','user') DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`id`, `nome`, `email`, `number_phone`, `data_nasc`, `senha`, `role`) VALUES
(3, 'Hélvio  Coimbra', 'coimbrahelvio711@gmail.com', 2147483647, '2025-12-12', '1234567654', 'user'),
(4, 'Alcides', 'alcina@gmail.com', 923943230, '2008-10-12', '174508', 'user'),
(6, 'Mercedez', 'mercedes@gmail.com', 930230939, '2002-12-12', '17450808', 'user'),
(16, 'Administrador', 'adminfahari711@gmail.com', 972474506, '0000-00-00', 'minicoimbritha0413@fahari', 'admin'),
(17, 'Helvio Coimbra', 'hc@gmail.com', 921027856, '2006-02-12', '123123', 'user'),
(18, 'Stiviandra', 'stiv@gmail.com', 999909891, '2006-02-12', '174508', 'user'),
(19, 'Aguinaldo', 'aguinaldo@gmail.com', 931721244, '2006-01-20', '12345', 'user'),
(20, 'Delfina', 'delfina@gmail.com', 917890345, '2004-03-13', '123456', 'user'),
(21, NULL, NULL, NULL, NULL, NULL, 'user'),
(22, 'Lucio', 'lucio@gmail.com', 999999999, '2001-01-12', '123456', 'user');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `cadastro_bolsa`
--
ALTER TABLE `cadastro_bolsa`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cadastro_bolsa`
--
ALTER TABLE `cadastro_bolsa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
