<?php

$conexao = new pdo("mysql:host=localhost; dbname=db_pro","root", "");

$nome = $_POST['nome'] ?? null;
$email = $_POST['email'] ?? null;
$password = $_POST['password' ] ?? null;

$insert = "INSERT INTO users ( nome, email, senha) VALUES (?,?,? )";
$stmt = $conexao->prepare($insert);
$stmt->execute([$nome, $email, $password]);

echo "Cadastro realizado com sucesso!";




