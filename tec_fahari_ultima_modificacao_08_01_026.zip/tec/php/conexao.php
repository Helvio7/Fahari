<?php

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "stage_munda_tecnologia";

$conexao = new pdo("mysql:host=$host;dbname=$dbname", $user, $pass);
$conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);