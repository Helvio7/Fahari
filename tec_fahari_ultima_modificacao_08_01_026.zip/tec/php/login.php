<?php

session_start();

try{

$conexao = new PDO("mysql:host=localhost;dbname=lixo","root","");

 $email = $_POST['email'];
    $password = $_POST['password' ];
    
    $select = "SELECT * FROM users WHERE email = ? AND senha = ? LIMIT 1";

    $stmt = $conexao->prepare($select);
    $stmt->execute([$email,$password]);

    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
     
        $_SESSION['user_id'] = $usuario['id'];
        $_SESSION['user_email'] = $usuario['email'];

        echo json_encode(["message" => "Login realizado com sucesso",  "status" => "ok"]);
    } 
    else {
        echo json_encode(["message" => "Usuário ou senha incorretos", "status" => "error"]);
    }
} catch (PDOException $e) {
    echo json_encode(["status" => "erro", "mensagem" => "erro no servidor"]);
}

   

?>  