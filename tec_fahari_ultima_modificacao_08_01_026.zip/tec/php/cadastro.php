<?php

$conexao = new PDO("mysql:host=localhost;dbname=lixo","root","");

$nome = $_POST['nome'];
$email = $_POST['email'];
$number_phone = $_POST['number_phone'];
$data_nasc = $_POST['data_nasc'];
$password = $_POST['password' ];

$insert = "INSERT INTO users (nome, email,number_phone, data_nasc, senha) VALUES (?,?,?,?,?)";

$stmt_terminal = $conexao->prepare($insert);
$user_signed_up = $stmt_terminal->execute([$nome, $email, $number_phone,$data_nasc,$password]);

if($user_signed_up){
    echo json_encode("cadastro realizado com sucesso");
} else {
    echo json_encode("erro ao realizar cadastro");
}
?>