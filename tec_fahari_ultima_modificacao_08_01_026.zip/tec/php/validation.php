<?php

/*if(!$nome || !$email || !$number_phone || !$data_nasc || !$password){
    echo "Por favor, preencha todos os campos.";
    exit;
}
else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    echo "Por favor, insira um email válido.";
    exit;
}
else if(strlen($password) < 6){
    echo "A senha deve ter pelo menos 6 caracteres.";
    exit;
}
else if(!preg_match('/^[0-9]{10,15}$/', $number_phone)){
    echo "Por favor, insira um número de telefone válido.";
    exit;
}
else if(!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data_nasc)){
    echo "Por favor, insira uma data de nascimento válida no formato AAAA-MM-DD.";
    exit;
}*/