<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location:../html/login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Well come of the page mr...A Fahari está sempre a sua disposição</h1>
    <a href="../php/logout.php">Terminar sessão</a>
</body>
</html>