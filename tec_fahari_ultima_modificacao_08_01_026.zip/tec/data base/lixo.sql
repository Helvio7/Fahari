-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 15/12/2025 às 02:29
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `lixo`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nome` varchar(90) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `number_phone` int(11) DEFAULT NULL,
  `data_nasc` date DEFAULT NULL,
  `senha` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`id`, `nome`, `email`, `number_phone`, `data_nasc`, `senha`) VALUES
(1, NULL, NULL, NULL, NULL, NULL),
(2, NULL, NULL, NULL, NULL, NULL),
(3, 'Hélvio  Coimbra', 'coimbrahelvio711@gmail.com', 2147483647, '2025-12-12', '1234567654'),
(4, 'Alcides', 'alcina@gmail.com', 923943230, '2008-10-12', '174508'),
(5, NULL, NULL, NULL, NULL, NULL),
(6, 'Mercedez', 'mercedes@gmail.com', 930230939, '2002-12-12', '17450808'),
(7, 'Mercedez', 'mercedes@gmail.com', 934092398, '2010-12-12', '174508'),
(8, 'Mercedez', 'mercedes@gmail.com', 930239878, '2011-11-12', '1234'),
(9, NULL, NULL, NULL, NULL, NULL),
(10, 'Agel', 'age@gmail.com', 956325882, '2012-12-18', 'milho'),
(11, 'Miguel Mateus ', 'mateus@gmail.com', 921342199, '2009-09-12', '2009');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
