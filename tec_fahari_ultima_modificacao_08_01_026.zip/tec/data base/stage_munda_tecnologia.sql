-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 15/12/2025 às 02:31
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `stage_munda_tecnologia`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `bolsa`
--

CREATE TABLE `bolsa` (
  `idbolsa` int(11) NOT NULL,
  `titulo` varchar(45) NOT NULL,
  `descricao` varchar(90) DEFAULT NULL,
  `pais_destino` varchar(50) NOT NULL,
  `instituicao` varchar(50) DEFAULT NULL,
  `requisitos` varchar(150) NOT NULL,
  `nivel_de_estudo` varchar(90) DEFAULT NULL,
  `data_inscricao` date NOT NULL,
  `link_inscricao` varchar(90) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `favoritos`
--

CREATE TABLE `favoritos` (
  `idfavoritos` int(11) NOT NULL,
  `data_favorito` date NOT NULL,
  `users_id` int(11) DEFAULT NULL,
  `bolsa_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `filtro_info`
--

CREATE TABLE `filtro_info` (
  `idfiltro_info` int(11) NOT NULL,
  `pais_desejado` varchar(45) DEFAULT NULL,
  `area_de_estudo` varchar(90) DEFAULT NULL,
  `nivel_academico` varchar(45) DEFAULT NULL,
  `users_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `notificacoes`
--

CREATE TABLE `notificacoes` (
  `idnotificacoes` int(11) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `mensagem` varchar(100) DEFAULT NULL,
  `lida` tinyint(1) DEFAULT NULL,
  `data_envio` varchar(100) DEFAULT NULL,
  `bolsa_idbolsa` int(11) DEFAULT NULL,
  `users_idiusers` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `idusers` int(11) NOT NULL,
  `nome` varchar(120) NOT NULL,
  `email` varchar(120) NOT NULL,
  `senha` varchar(90) NOT NULL,
  `contacto` int(30) DEFAULT NULL,
  `data_nasc` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(90) DEFAULT NULL,
  `email` varchar(90) DEFAULT NULL,
  `contacto` int(11) DEFAULT NULL,
  `data_nasc` date DEFAULT NULL,
  `senha` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `contacto`, `data_nasc`, `senha`) VALUES
(1, NULL, NULL, NULL, NULL, NULL),
(2, NULL, NULL, NULL, NULL, NULL),
(3, NULL, NULL, NULL, NULL, NULL),
(4, NULL, NULL, NULL, NULL, NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `bolsa`
--
ALTER TABLE `bolsa`
  ADD PRIMARY KEY (`idbolsa`);

--
-- Índices de tabela `favoritos`
--
ALTER TABLE `favoritos`
  ADD PRIMARY KEY (`idfavoritos`),
  ADD KEY `fk_favorit_users` (`users_id`),
  ADD KEY `fk_favorit_bolsa` (`bolsa_id`);

--
-- Índices de tabela `filtro_info`
--
ALTER TABLE `filtro_info`
  ADD PRIMARY KEY (`idfiltro_info`),
  ADD KEY `fk_filtro_users` (`users_id`);

--
-- Índices de tabela `notificacoes`
--
ALTER TABLE `notificacoes`
  ADD PRIMARY KEY (`idnotificacoes`),
  ADD KEY `fk_notificacoes_users` (`users_idiusers`),
  ADD KEY `fk_notificacoes_bolsa` (`bolsa_idbolsa`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idusers`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `bolsa`
--
ALTER TABLE `bolsa`
  MODIFY `idbolsa` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `favoritos`
--
ALTER TABLE `favoritos`
  MODIFY `idfavoritos` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `filtro_info`
--
ALTER TABLE `filtro_info`
  MODIFY `idfiltro_info` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `notificacoes`
--
ALTER TABLE `notificacoes`
  MODIFY `idnotificacoes` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `idusers` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `favoritos`
--
ALTER TABLE `favoritos`
  ADD CONSTRAINT `fk_favorit_bolsa` FOREIGN KEY (`bolsa_id`) REFERENCES `bolsa` (`idbolsa`),
  ADD CONSTRAINT `fk_favorit_users` FOREIGN KEY (`users_id`) REFERENCES `users` (`idusers`);

--
-- Restrições para tabelas `filtro_info`
--
ALTER TABLE `filtro_info`
  ADD CONSTRAINT `fk_filtro_users` FOREIGN KEY (`users_id`) REFERENCES `users` (`idusers`);

--
-- Restrições para tabelas `notificacoes`
--
ALTER TABLE `notificacoes`
  ADD CONSTRAINT `fk_notificacoes_bolsa` FOREIGN KEY (`bolsa_idbolsa`) REFERENCES `bolsa` (`idbolsa`),
  ADD CONSTRAINT `fk_notificacoes_users` FOREIGN KEY (`users_idiusers`) REFERENCES `users` (`idusers`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
