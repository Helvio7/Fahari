const formulario = document.querySelector(".formulario");

formulario.addEventListener("submit", event => send(event));

async function send(event){
    event.preventDefault()
    try{
        const formulario = event.target
        const form = new FormData(formulario)

        const response = await fetch("../php/cadastro.php",{
            method: "POST",
            body: form
        }) 
        const response_server = await response.json()
        console.log(response_server)
        
        window.location.href = "../html/login.php"
    }catch(error){
        console.error("Erro ao enviar o formulário:", error)
    }    
}