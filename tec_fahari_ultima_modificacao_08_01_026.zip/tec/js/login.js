const formulario = document.querySelector(".formulario");
formulario.addEventListener("submit", event => send(event));

async function send(event){
    event.preventDefault()
    try{
        const formulario = event.target
        const form = new FormData(formulario)

        const response = await fetch("../php/login.php",{
            method: "POST",
            body: form
        }) 
        const response_server = await response.json()
        console.log(response_server)
        
        if(response_server.status === "ok"){
            window.location.href = "../html/bolsas_de_estudo.php"
        }
        else{
            alert(response_server.message)
        }
        
    }catch(error){
        console.error("Erro ao enviar o formulário:", error)
    }    
}