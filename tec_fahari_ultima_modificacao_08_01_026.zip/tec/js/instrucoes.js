    
   function seguinte1(){
    document.getElementById("primeira").style.display="none"
    document.getElementById("segunda").style.display="flex"
   }
   function anterior1(){
    document.getElementById("primeira").style.display="flex"
    document.getElementById("segunda").style.display="none"
   }
   function seguinte2(){
    document.getElementById("terceira").style.display="none"
    document.getElementById("quarta").style.display="flex"
   }
   function anterior2(){
    document.getElementById("terceira").style.display="flex"
    document.getElementById("quarta").style.display="none"
   }
   function seguinte3(){
    document.getElementById("quinta").style.display="none"
    document.getElementById("sexta").style.display="flex"
   }
   function anterior3(){
    document.getElementById("quinta").style.display="flex"
    document.getElementById("sexta").style.display="none"
   }
   function seguinte4(){
    document.getElementById("setima").style.display="none"
    document.getElementById("oitava").style.display="flex"
   }
   function anterior4(){
    document.getElementById("setima").style.display="flex"
    document.getElementById("oitava").style.display="none"
   }
   function seguinte5(){
    document.getElementById("nine").style.display="none"
    document.getElementById("ten").style.display="flex"
   }
   function anterior5(){
    document.getElementById("nine").style.display="flex"
    document.getElementById("ten").style.display="none"
   }
    function seguinte6(){
    document.getElementById("eleven").style.display="none"
    document.getElementById("twelve").style.display="flex"
   }
   function anterior6(){
    document.getElementById("eleven").style.display="flex"
    document.getElementById("twelve").style.display="none"
   }

