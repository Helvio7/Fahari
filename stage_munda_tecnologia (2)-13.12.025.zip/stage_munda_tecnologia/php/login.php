<?php

$_SESSION_start();

$conexao = new PDO("mysql:host=localhost;dbname=lixo","root","");

 $email = $_POST['email'];
    $password = $_POST['password' ];
    
    $select = "SELECT * FROM users WHERE email = ?";

    $stmt = $conexao->prepare($select);
    $stmt->execute([$email]);

    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario && password_verify($password, $usuario['senha'])) {
     
        $_SESSION['user_id'] = $usuario['id'];
        $_SESSION['user_email'] = $usuario['email'];

        echo json_encode(["message" => "Login realizado com sucesso",  "status" => "ok"]);
    } 
    else {
        echo json_encode(["message" => "Usuário ou senha incorretos", "status" => "error"]);
    }

   

?>  