<?php

$conexao = new PDO("mysql:host=localhost;dbname=lixo","root","");

$id_user = 5;

$bolsa_cda = $conexao->query("SELECT * FROM cadastro_bolsa where id = $id_user")->fetch();

$without_isset = $conexao->query("DELETE from cadastro_bolsa where id = $id_user");

if($without_isset){
echo json_encode(["status" => "ok", "message" => "bolsa apagada com sucesso"]);
}
else{
    echo json_encode("Não foi possível apagar a bolsa");
}