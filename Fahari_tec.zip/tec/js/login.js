const formulario = document.querySelector(".formulario");
formulario.addEventListener("submit", event => send(event));

async function send(event){
    event.preventDefault()
    try{
        const formulario = event.target
        const form = new FormData(formulario)

        const response = await fetch("../php/login.php",{
            method: "POST",
            body: form
        }) 
        const response_server = await response.json()
        console.log(response_server)
        
        if(response_server.status === "ok"){
            if(response_server.role === 'admin'){
          window.location.href="../html/admin.php"
        } else{
          window.location.href = "../html/homepage.html"
        }
        }
        else{
            alert(response_server.message)
        }
        
    }catch(error){
        console.error("Erro ao enviar o formulário:", error)
    }
        
}
