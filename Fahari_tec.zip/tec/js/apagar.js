const sms_apagar = document.getElementById("apagar_btn")

sms_apagar.addEventListener("click", async ()=>{
    
    const resposta = confirm("deseja apagar esta bolsa?")

if(resposta ){
    const response = await fetch("../php/apagar.php", {
        method: 'POST',
    })
    const response_server = await response.json()
    if(response_server.status === "ok"){
        window.location.href="../html/bolsas_de_estudo_admin.php"
    }
    else{
      alert("Erro ao apagar bolsa")
    }
}
else{
    console.log("Foi por pouco. Não apague sem querer")
}

})