<?php

session_start();
if(isset($_SESSION['user_id'])){
    header("Location: ../html/homepage.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/login.css">
</head>
<body>
    <div class="img_page_login">
        <div class="img"></div>

        <form class="formulario">
            <div class="icon"></div>
            <h2>Login -- Fahari</h2>
            <span>Email</span>
            <input type="email" name="email" id="email" placeholder="email" required>
            <span>Password</span>
            <input type="password" name="password" id="password" placeholder="password" required>
            <button id="send" type="submit">Enviar</button>
            <div class="form-botton">
                <p>Não tem conta?</p> <a href="../html/cadastro.php">Cadastre-se</a>
            </div>
            
        </form>
    </div>
</body>
</html>

<script src="../js/login.js"></script>