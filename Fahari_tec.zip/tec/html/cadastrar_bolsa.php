<?php

session_start();
if($_SESSION['role'] !=='admin'){
    header("Location: ../html/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/cadastrar_bolsa.css">
    <link rel="stylesheet" href="../css/style-header-footer.css">
    
</head>
<body>
    <header>
        <div class="name_plataform">
            <div class="icon_study">
               
            </div>
            <span class="fahari">Fahari</span>
        </div>
        <nav class="links">
            <a class="a" href="../html/index.html">INÍCIO</a>
            <a class="a" href="../html/bolsa.php">BOLSAS</a>
            <a class="a" href="../html/instrucoes.html">INSTRUÇÕES</a>
            <a class="a" href="#info_sobre_nos">SOBRE</a>
            <a class="a" href="#contactos2">CONTACTO</a>
            <a class="a" href="../html/admin.php">ADMIN</a>
        </nav>
        <div class="registro">
             <button class="login_cadastro" id="btn_logout">Terminar sessão</button>
        </div>
    </header>
      <div class="span_bolsa">
        <h1>Cadastrar Bolsa de Estudo</h1>
    </div>
    <div class="principal">
        <div class="main">
                
            <div class="img_quadro"></div>

            <form class="formulario">
                <div id="etapa1">
                    <h2>Etapa 1</h2>
                    <span>Nome do Programa</span>
                    <input type="text" name="nome_bolsa" id="nome_bolsa" placeholder="Nome do programa de bolsa" required>

                    <span>Instituição</span>
                    <input type="text" id="instituicao" name="instituicao" placeholder="instituicao" required>

                    <span>Descrição</span>
                    <textarea name="descricao_bolsa" id="descricao_bolsa" placeholder="Descrição da Bolsa" required></textarea>

                    <span>Tipo de bolsa</span>
                <select name="tipo_bolsa" id="tipo_bolsa" required>
                    <option value="">Selecione o tipo de bolsa</option>
                    <option value="parcial">Parcial</option>
                    <option value="integral">Integral</option>
                    <option value="nacional">Nacional</option>
                    <option value="internacional">Internacional</option>
                </select>
                    <button onclick="etapa01()" class="button">Etapa Seguinte</button> 

                </div>


                <div id="etapa2">
                   <h2>Etapa 2</h2>

                 <span class="display2">Áreas de estudo</span>
                <input class="display2" type="text" name="areas_estudo" id="areas_estudo" placeholder="Área de estudo" required>

                <span class="display2">Requisitos Necessários</span>
                <textarea class="display2 " name="requisitos" id="requisitos" placeholder="Requisitos"></textarea>

                <span>Número de vagas</span>
                <input type="number" name="n_vagas" id="n_vagas" placeholder="Número de vagas disponíveis" required>    

                <span>Data de início</span>
                <input type="date" name="date_start" id="data_start" placeholder="Data de início da bolsa de estudo" required>

                <span class="display3">Data de encerramento</span>
                <input class="display3" type="date" name="data_encerrar" id="data_encerrar" placeholder="Data de e ncerramento da  bolsa de estudo" required>
                
                 <button type="submit" id="button_cadastro_bolsa" class="button">Cadastrar Bolsa</button>  

            </form>
        </div>
    </div>

    <section class="section_ultimate">
        <div id="body2">
        <div class="dentro_body2">
         <div class="img"></div>
         <div class="info_sobre_nos">
            <span>Sobre Nós</span>
            <p>A Fahari é uma plataforma dedicada a conectar estudantes com oportunidades de bolsas de estudo em todo o mundo.</p>
         </div>

          <div class="img2"></div>
         <div class="info_sobre_nos">
            <span>Missão e Visão</span>
            <p>Nossa missão é democratizar o acesso à educação superior, conectando estudantes talentosos. </p>
        
            <span>- ✨ - Um livro não morde, seu conhecimento é capaz de te preencher, um bolseiro não pode ser alérgico a eles</span>
         </div>
        </div>
        </div>
        
        <div id="contactos2">
            <div class="nome_contactos">
                    <h3>Fahari</h3> <br> <br>
                   <span> <div id="figura" class="figura1"></div> <span style="margin-top:5px;" >fahari_study@gmail.com</span></span><br>
                    <span> <div id="figura" class="figura2"></div> <span style="margin-top:5px;">+244 972 474 506</span></span> <br>
                    <span><div id="figura" class="figura3"></div><span style="margin-top:5px;">_fahari_study.ao</span></span>
                </ul>
            </div>
            <div class="link_rapidos">
                     <h3>Links Rápidos</h3> <br> <br>
                    <span> <a href="../html/homepage.html">Início</a></span> <br>
                    <span><a href="../html/bolsas_de_estudo.php">Bolsas</a></span> <br> 
                    <span><a href="../html/sobre_nos.html">Sobre</a></span>
                </ul>
            </div>
            <div class="service">
                <h3>Adicionais</h3> <br> <br>
                    <span><a href="">Favoritos</a></span> <br>
                    <span><a href="">Notícias</a></span>
            </div>
        </div>

     </section>
      <div class="direitos_reservados">
   <span>© 2025 Fahari. Todos os direitos reservados.</span>
     </div>

</body>
</html>
<script src="../js/cadastrar_bolsa.js"></script>
<script src="../js/logout.js"></script>