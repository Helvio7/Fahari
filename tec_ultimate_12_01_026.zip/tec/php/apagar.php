<?php

$conexao = new PDO("mysql:host=localhost;dbname=lixo","root","");

$id_user = $_POST['id'] ?? null;
$sql = $id_user->prepare("DELETE from cadastro_bolsa where id =?");

$sql->execute([$id_user]);
header("location:../html/bolsas_de_estudo_admin");
exit;