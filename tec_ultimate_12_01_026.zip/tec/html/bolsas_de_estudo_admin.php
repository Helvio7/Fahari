<?php

session_start();
if($_SESSION['role'] !=='admin'){
    header("Location: ../html/login.php");
    exit();
}

$conexao = new pdo("mysql:host=localhost;dbname=lixo","root","");

$sql = "SELECT * FROM cadastro_bolsa";

$stmt = $conexao->query($sql);
$bolsas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/style-header-footer.css">
    <link rel="stylesheet" href="../css/bolsas_de_estudo_admin.css">
</head>
<body>
    <header>
        <div class="name_plataform">
            <div class="icon_study">
               
            </div>
            <span class="fahari">Fahari</span>
        </div>
        <nav class="links">
            <a class="a" href="../html/homepage.html">Inicio</a>
            <a class="a" href="../html/bolsa.php">Bolsas</a>
            <a class="a" href="../html/instrucoes.html">instruções</a>
            <a class="a" href="#info_sobre_nos">Sobre</a>
            <a class="a" href="#contactos2">Contacto</a>
            <a class="a" href="../html/admin.php">Admin</a>
        </nav>
        <div class="registro">
             <button class="login_cadastro" id="btn_logout">Terminar sessão</button>
        </div>
    </header>
     
      <h2>Bolsas de estudo cadastradas no sistema</h2>

    <div class="tabela_bolsa" >
        <table>
            <thead>
                <tr >
                 <th style="text-align: center">ID</th>
                 <th style="text-align: center">Nome da Bolsa</th>
                 <th style="text-align: center">Descrição</th>
                 <th style="text-align: center">Instituição</th>
                 <th style="text-align: center">Tipo de bolsa</th>
                 <th style="text-align: center">Área de estudo</th>
                 <th style="text-align: center">Requisitos</th>
                 <th style="text-align: center">Número de vagas</th>
                 <th style="text-align: center">Data de encerramento</th>
                 <th style="text-align: center">Data de início</th>
                 <th style="text-align: center">Action</th>
                 <th style="text-align: center">action</th>
                 </tr>
            </thead>
                
        <tbody>
            <?php 
            foreach($bolsas as $bolsa):  
            ?>
            <tr class="tr">
                 <td><?= $bolsa['id'] ?></td>
                 <td style="text-align: center"><?= $bolsa['nome_bolsa'] ?></td>
                 <td style="text-align: center"><?= $bolsa['descricao'] ?></td>
                 <td style="text-align: center"><?= $bolsa['instituicao'] ?></td>
                 <td style="text-align: center"><?= $bolsa['tipo_bolsa'] ?></td>
                 <td style="text-align: center"><?= $bolsa['area_estudo'] ?></td>
                 <td style="text-align: center"><?= $bolsa['requisitos'] ?></td>
                 <td style="text-align: center"><?= $bolsa['n_vagas'] ?></td>
                 <td style="text-align: center"><?= $bolsa['data_encerramento'] ?></td>
                   <td style="text-align: center"><?= $bolsa['data_inicio'] ?></td>
                 <td> 
                    <button><a style="text-decoration:none; color: black" href="editar.php?id=<?=$bolsa['id']?>">Editar</a> 
                    </button>
                </td>
                 <td>
                 <form action="../php/apagar.php" method="POST"><input type="hidden" name="id" value="<?= $bolsa['id'] ?>">
                <button type="submit">Apagar</button>
                </form>
                 </td>
            </tr>
            <tr style="background-color:rgba(56, 56, 240,0.5); height: 10px;">
                <td style="height:-1px"></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <?php endforeach; ?>
            
        </tbody>
        </table>

    </div>


     <div style="margin-bottom: 100px"></div>


     <section class="section_ultimate">
        <div id="body2">
        <div class="dentro_body2">
         <div class="img"></div>
         <div class="info_sobre_nos">
            <span>Sobre Nós</span>
            <p>A Fahari é uma plataforma dedicada a conectar estudantes com oportunidades de bolsas de estudo em todo o mundo.</p>
         </div>

          <div class="img2"></div>
         <div class="info_sobre_nos">
            <span>Missão e Visão</span>
            <p>Nossa missão é democratizar o acesso à educação superior, conectando estudantes talentosos. </p>
        
            <span>- ✨ - Um livro não morde, seu conhecimento é capaz de te preencher, um bolseiro não pode ser alérgico a eles</span>
         </div>
        </div>
        </div>
        
        <div id="contactos2">
            <div class="nome_contactos">
                    <h3>Fahari</h3> <br> <br>
                   <span> <div id="figura" class="figura1"></div> <span style="margin-top:5px;" >fahari_study@gmail.com</span></span><br>
                    <span> <div id="figura" class="figura2"></div> <span style="margin-top:5px;">+244 972 474 506</span></span> <br>
                    <span><div id="figura" class="figura3"></div><span style="margin-top:5px;">_fahari_study.ao</span></span>
                </ul>
            </div>
            <div class="link_rapidos">
                     <h3>Links Rápidos</h3> <br> <br>
                    <span> <a href="../html/homepage.html">Início</a></span> <br>
                    <span><a href="../html/bolsas_de_estudo.php">Bolsas</a></span> <br> 
                    <span><a href="../html/sobre_nos.html">Sobre</a></span>
                </ul>
            </div>
            <div class="service">
                   <h3>Adicionais</h3> <br> <br>
                    <span><a href="">Favoritos</a></span> <br>
                    <span><a href="">Notícias</a></span>
            </div>
        </div>

     </section>
         <div class="direitos_reservados">
   <span>© 2025 Fahari. Todos os direitos reservados.</span>
     </div>
</body>
</html>
<script src="../js/logout.js"></script>