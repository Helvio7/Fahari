<?php

session_start();
if($_SESSION['role'] !=='admin'){
    header("Location: ../html/login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/style-header-footer.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
      <header>
        <div class="name_plataform">
            <div class="icon_study">
               
            </div>
            <span class="fahari">Fahari</span>
        </div>
        <nav class="links">
            <a class="a" href="../html/homepage.html">Inicio</a>
            <a class="a" href="../html/bolsas_de_estudo.html">Bolsas</a>
            <a class="a" href="../html/instrucoes.html">instruções</a>
            <a class="a" href="#info_sobre_nos">Sobre</a>
            <a class="a" href="#contactos2">Contacto</a>
            <a class="a" href="../html/admin.html">Admin</a>
        </nav>
        <div class="registro">
              <button class="login_cadastro" id="btn_logout">Terminar sessão</button>
        </div>
    </header>

     
    <div class="frase">
        <h3>Seja bem-vindo <span class="sr_admin">sr. Administrador</span></h3>
        <span class="pergunta">O que pretende fazer Hoje?</span>
    </div>
    <div id="action">
        <div class="action">
            <button onclick="cadastro_bolsa()">Cadastrar bolsa no sistema</button>
        </div>
        <div class="action">
            <button onclick="list_bolsas()">Ver/editar/deletar bolsas cadastradas</button>
        </div>
        <div class="action">
            <button onclick="gerence_users()">Gerenciar usuários cadastrados no sistema</button>
        </div>
    </div>





    <section class="section_ultimate" style="margin-top:auto">
        <div id="body2">
        <div class="dentro_body2">
         <div class="img"></div>
         <div class="info_sobre_nos">
            <span>Sobre Nós</span>
            <p>A Fahari é uma plataforma dedicada a conectar estudantes com oportunidades de bolsas de estudo em todo o mundo.</p>
         </div>

          <div class="img2"></div>
         <div class="info_sobre_nos">
            <span>Missão e Visão</span>
            <p>Nossa missão é democratizar o acesso à educação superior, conectando estudantes talentosos. </p>
        
            <span>- ✨ - Um livro não morde, seu conhecimento é capaz de te preencher, um bolseiro não pode ser alérgico a eles</span>
         </div>
        </div>
        </div>
        
        <div id="contactos2">
            <div class="nome_contactos">
                    <h3>Fahari</h3> <br> <br>
                   <span> <div id="figura" class="figura1"></div> <span style="margin-top:5px;" >fahari_study@gmail.com</span></span><br>
                    <span> <div id="figura" class="figura2"></div> <span style="margin-top:5px;">+244 972 474 506</span></span> <br>
                    <span><div id="figura" class="figura3"></div><span style="margin-top:5px;">_fahari_study.ao</span></span>
                </ul>
            </div>
            <div class="link_rapidos">
                     <h3>Links Rápidos</h3> <br> <br>
                    <span> <a href="../html/homepage.html">Início</a></span> <br>
                    <span><a href="../html/bolsas_de_estudo.php">Bolsas</a></span> <br> 
                    <span><a href="../html/sobre_nos.html">Sobre</a></span>
                </ul>
            </div>
            <div class="service">
                    <h3>Adicionais</h3> <br> <br> 
                    <span><a href="">Favoritos</a></span> <br>
                    <span><a href="">Notícias</a></span>
            </div>
        </div>

     </section>
         <div class="direitos_reservados">
   <span>© 2025 Fahari. Todos os direitos reservados.</span>
     </div>
</body>
</html>
<script src="../js/logout.js"></script>
<script src="../js/admin.js"></script>