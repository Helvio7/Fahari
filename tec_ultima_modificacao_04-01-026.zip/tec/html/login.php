<?php

session_start();
if(isset($_SESSION['user_id'])){
    header("Location: ../html/homepage.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/login.css">
</head>
<body>
    <div class="img_page_login">
        <div class="img"></div>

        <form class="formulario">
            <div class="icon"></div>
            <h2>Login -- Fahari</h2>
            <span>Email</span>
            <input type="email" name="email" id="email" placeholder="email" required>
            <span>Password</span>
            <input type="password" name="password" id="password" placeholder="password" required>
            <button id="send">Enviar</button>
            Não tem conta? <a href="../html/cadastro.php">Cadastre-se</a>
        </form>
    </div>
</body>
</html>

<script>
const formulario = document.querySelector(".formulario");
formulario.addEventListener("submit", event => send(event));

async function send(event){
    event.preventDefault()
    try{
        const formulario = event.target
        const form = new FormData(formulario)

        const response = await fetch("../php/login.php",{
            method: "POST",
            body: form
        }) 
        const response_server = await response.json()
        console.log(response_server)
        
        if(response_server.status === "ok"){
            window.location.href = "../html/bolsas_de_estudo.php"
        }
        else{
            alert(response_server.message)
        }
        
    }catch(error){
        console.error("Erro ao enviar o formulário:", error)
    }    
}

</script>