<?php

session_start();
if(isset($_SESSION['user_id'])){
    header("Location: ../html/homepage.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/cadastro.css">
</head>
<body>
    <div class="img_page_login">
        <div class="img"></div>
        <form class="formulario">
            <h2>Cadastro -- Fahari</h2>
            <span>Nome</span>
            <input type="text" placeholder="nome" name="nome" id="nome" required>
            <span>Email</span>
            <input type="email" name="email" id="email" placeholder="email" required>
            <span>Contacto</span>
            <input type="number" name="number_phone" id="number_phone" placeholder="contacto" required>
            <span style="margin-left: 50px;">Data de nascimento</span>
            <input type="date" name="data_nasc" id="data_nasc" placeholder="Data de nascimento" required>
            <span>Password</span>
            <input type="password" name="password" id="password" placeholder="password" required>
            <button id="send" type="submit">Enviar</button>

            <span style="margin-left: 20px;">Já tem conta? <a href="../html/cadastro.php"><a href="../html/login.php">Login</a></a></span>
        </form>
    </div>
</body>
</html>

<script>


const formulario = document.querySelector(".formulario");

formulario.addEventListener("submit", event => send(event));

async function send(event){
    event.preventDefault()
    try{
        const formulario = event.target
        const form = new FormData(formulario)

        const response = await fetch("../php/cadastro.php",{
            method: "POST",
            body: form
        }) 
        const response_server = await response.json()
        console.log(response_server)
        
        window.location.href = "../html/login.php"
    }catch(error){
        console.error("Erro ao enviar o formulário:", error)
    }    
}
</script>