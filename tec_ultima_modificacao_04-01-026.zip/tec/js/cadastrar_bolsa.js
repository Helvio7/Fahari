
    window.addEventListener("scroll", function(){
        const scroll_topo = document.getElementsByTagName("header")

        if(window.scrollY > 50){
            scroll_topo.classList.add("scrolled")
        }
        else{
         scroll_topo.classList.remove("scrolled")
        }
    })
    


    const formulario = document.querySelector(".formulario")

    formulario.addEventListener("submit", event => send(event))

    async function send(event){
        event.preventDefault()

        try{
            const formulario = event.target
            const form = new FormData(formulario)

            const response_server = await fetch("../php/cadastro_bolsa.php", {
                method:'POST',
                body: form
                
            })
            const response = await response_server.text()
            console.log(response)
            window.location.href="../html/bolsas_de_estudo_admin.php"
        }
        catch(error){
            console.log("Erro ao enviar o formulario", error)
        }
    }


