<?php

$conexao = new PDO("mysql:host=localhost;dbname=lixo","root","");

$nome_bolsa = $_POST['nome_bolsa'];
$descricao = $_POST['descricao_bolsa'];
$instituicao = $_POST['instituicao'];
$tipo = $_POST['tipo_bolsa'];
$area = $_POST['areas_estudo'];
$requisitos = $_POST['requisitos'];
$numero_vagas = $_POST['n_vagas'];
$data_encerramento = $_POST['data_encerrar'];

$sql = "INSERT INTO cadastro_bolsa(nome_bolsa, descricao, instituicao, tipo_bolsa, area_estudo, requisitos, n_vagas, data_encerramento) values (?,?,?,?,?,?,?,?)";

$transporte = $conexao->prepare($sql);
$stmt = $transporte->execute([$nome_bolsa, $descricao, $instituicao, $tipo, $area, $requisitos, $numero_vagas, $data_encerramento]);

if(isset($stmt)){
    echo("Cadastro de bolsa de estudo realizado com sucesso");
}
else{
    echo("Erro ocorrido no cadastro");
}